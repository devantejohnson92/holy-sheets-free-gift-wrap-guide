Holy Sheets Templates - 12 transparent 300 DPI PNG gift tags.
Print at 300 DPI for true size (2.5 x 3.6 in (6.4 x 9.1 cm)).
Personal use only. Not for resale or redistribution. Digital download, no physical item shipped.
(c) 2026 Holy Sheets Templates
