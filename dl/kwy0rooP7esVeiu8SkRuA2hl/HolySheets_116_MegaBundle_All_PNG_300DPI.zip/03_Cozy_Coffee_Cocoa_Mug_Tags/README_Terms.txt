Holy Sheets Templates - 12 transparent 300 DPI PNG gift tags.
Print at 300 DPI for true size (3.0 x 2.8 in (7.6 x 7.1 cm)).
Personal use only. Not for resale or redistribution. Digital download, no physical item shipped.
(c) 2026 Holy Sheets Templates
