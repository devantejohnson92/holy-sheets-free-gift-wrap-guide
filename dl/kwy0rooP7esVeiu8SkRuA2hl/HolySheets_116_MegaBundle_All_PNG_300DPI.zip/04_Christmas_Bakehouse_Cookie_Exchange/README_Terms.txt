Holy Sheets Templates - 12 transparent 300 DPI PNG gift tags.
Print at 300 DPI for true size (2.6 x 3.2 in (6.6 x 8.1 cm)).
Personal use only. Not for resale or redistribution. Digital download, no physical item shipped.
(c) 2026 Holy Sheets Templates
