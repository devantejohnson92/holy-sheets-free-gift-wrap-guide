Sarcastic Office Gift Tags - Holy Sheets Templates
Individual 300 DPI PNG files with transparent backgrounds.
All 12 tags 2.6 x 3.8 in (6 faux parcel labels + 6 HR ticket stubs).
For accurate sizing print the PDF at 100%. If you print a PNG, set it to the size listed above.
Personal use only. Not for resale or redistribution. Digital download - no physical item shipped.
