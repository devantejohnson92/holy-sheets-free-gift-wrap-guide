Heirloom Faith Christmas Tags - Holy Sheets Templates
Individual 300 DPI PNG files with transparent backgrounds.
8 cathedral arch tags 2.3 x 3.7 in + 4 eight-point star tags 2.8 x 3.2 in (plus 4 easy-cut 2.8 in round star tags).
For accurate sizing print the PDF at 100%. If you print a PNG, set it to the size listed above.
Personal use only. Not for resale or redistribution. Digital download - no physical item shipped.
