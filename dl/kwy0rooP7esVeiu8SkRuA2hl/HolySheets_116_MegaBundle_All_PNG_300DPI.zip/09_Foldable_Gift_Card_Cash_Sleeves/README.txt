Christmas Gift Card Holders - Holy Sheets Templates
Individual 300 DPI PNG files with transparent backgrounds.
Finished sleeve 4.0 x 2.75 in; inner pocket 4.0 x 2.75 in holds standard 3.375 x 2.125 in gift cards or folded bills; flat template 4.8 x 5.5 in, 2 per page.
For accurate sizing print the PDF at 100%. If you print a PNG, set it to the size listed above.
Personal use only. Not for resale or redistribution. Digital download - no physical item shipped.
