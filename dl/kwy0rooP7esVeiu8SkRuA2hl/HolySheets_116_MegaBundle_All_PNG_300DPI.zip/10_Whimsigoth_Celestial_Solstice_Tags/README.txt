Whimsigoth Celestial Gift Tags - Holy Sheets Templates
Individual 300 DPI PNG files with transparent backgrounds.
6 faceted hexagon tags 2.5 x 3.5 in + 6 celestial arch tags with moon finial 2.4 x 3.6 in.
For accurate sizing print the PDF at 100%. If you print a PNG, set it to the size listed above.
Personal use only. Not for resale or redistribution. Digital download - no physical item shipped.
