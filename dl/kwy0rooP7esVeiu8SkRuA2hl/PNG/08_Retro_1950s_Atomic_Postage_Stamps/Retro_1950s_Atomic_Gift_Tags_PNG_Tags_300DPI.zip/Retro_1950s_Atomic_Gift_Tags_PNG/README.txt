Retro 1950s Atomic Gift Tags - Holy Sheets Templates
Individual 300 DPI PNG files with transparent backgrounds.
8 perforated postage stamp tags 2.5 x 3.2 in + 4 starburst diamond tags 2.7 x 3.4 in (plus 8 straight-edge easy-cut stamps).
For accurate sizing print the PDF at 100%. If you print a PNG, set it to the size listed above.
Personal use only. Not for resale or redistribution. Digital download - no physical item shipped.
